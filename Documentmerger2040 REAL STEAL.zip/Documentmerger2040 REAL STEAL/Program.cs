﻿using System;  
using System.IO;  
using System. Text;  
  
class Test 
    {
        [STAThread]
        static void Main(string[] args)
        {
            int countedtext = 0;
            int i = 0;
            try
            {
                while(i ==0 ){
                    string endingdocument = ".txt";
                    
                    try{
//engineer gaming
                    Console.WriteLine("What is the name of document A?");
                    string firstdocumentname = Console.ReadLine();
                    

                    if (firstdocumentname.EndsWith(".txt")){
                        Console.WriteLine("Good it contains .txt");
                        string truedocumentname = firstdocumentname;
                    }
                    else{
                        string truefirstdocumentname = firstdocumentname + endingdocument;
                    }
                    string text = System.IO.File.ReadAllText(@"C:\Users\Public\TestFolder\WriteText.txt");
                    try  
                        {  
                        // Create a StreamReader  
                        using (StreamReader reader = new StreamReader(firstdocumentname))  
                        {  
                        string line;  
                        // Read line by line  
                        while ((line = reader.ReadLine()) != null)  
                        {  
                        Console.WriteLine(line);  
                        }  
                        }  
                        }  
                        catch (Exception exp)  
                        {  
                        Console.WriteLine(exp.Message);  
                        }  
                    }
                    catch{
                        Console.WriteLine("enter a vaild document");
                        continue;
                    }
                    try{
                       Console.WriteLine("What is the name of document B?");
                    string seconddocumentname = Console.ReadLine();

                    if (seconddocumentname.EndsWith(".txt")){
                        Console.WriteLine("Good it contains .txt");
                        string trueseconddocumentname = seconddocumentname;
                    }
                    else{
                        string trueseconddocumentname = seconddocumentname + endingdocument;
                    } 
                    }
                    
                    catch{
                        Console.WriteLine("enter a vaild document");
                        continue;
                    }
                   //StreamWriter sw = new StreamWriter(firstdocumentname);
                    //Write a line of text
                }
                
    
        }
        catch{

            Console.WriteLine("fugg");
        }
    }
}
